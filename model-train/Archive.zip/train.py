import os
import torch

# Engage the full Xeon Platinum architecture
torch.set_num_threads(120)

import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, IterableDataset
from torch.amp import GradScaler, autocast
import random
import copy
import numpy as np

import config
import models
import preprocess
from db_utils import db_connect, fetch_sensor_batch, get_time_bounds


class VehicleStreamer(IterableDataset):
    def __init__(self, split="train"):
        super().__init__()
        self.split = split

    def __iter__(self):
        conn, cursor = db_connect()
        cursor.execute(
            "SELECT table_name FROM information_schema.tables WHERE table_schema='public'"
        )
        all_tables = [r[0] for r in cursor.fetchall()]
        bounds_cache = {}
        CHUNK_SECONDS = 15

        while True:
            class_id = random.choice(list(config.CLASS_MAP.keys()))
            valid_ds = [
                ds
                for ds in config.TRAIN_DATASETS
                if class_id in config.DATASET_VEHICLE_MAP[ds]
            ]
            if not valid_ds:
                continue

            ds = random.choice(valid_ds)
            v_base = random.choice(config.DATASET_VEHICLE_MAP[ds][class_id])

            try:
                matching_tables = [
                    t for t in all_tables if f"{ds}_" in t and f"_{v_base}" in t
                ]
                if not matching_tables:
                    continue
                rs = random.choice(
                    list(set([t.split("_")[-1] for t in matching_tables]))
                )
                audio_table = next(
                    (t for t in matching_tables if "_audio_" in t and t.endswith(rs)),
                    None,
                )
                if not audio_table:
                    continue

                target_run_id = (
                    random.choice([8, 9]) if (ds == "m3nvc" and class_id == 0) else None
                )

                cache_key = f"{audio_table}_{target_run_id}"
                if cache_key not in bounds_cache:
                    bounds_cache[cache_key] = get_time_bounds(
                        cursor, audio_table, run_id=target_run_id
                    )
                min_t, max_t = bounds_cache[cache_key]

                duration = max_t - min_t
                if duration <= CHUNK_SECONDS:
                    continue

                # Split Logic
                t_bound = min_t + (duration * config.SPLIT_TRAIN)
                v_bound = t_bound + (duration * config.SPLIT_VAL)

                if self.split == "train":
                    win_start = random.uniform(min_t, t_bound - CHUNK_SECONDS)
                elif self.split == "val":
                    win_start = random.uniform(t_bound, v_bound - CHUNK_SECONDS)
                else:
                    win_start = random.uniform(v_bound, max_t - CHUNK_SECONDS)

                # FETCH RAW LISTS ONLY (Low CPU usage for workers)
                chunk_data = []
                for sensor in config.TRAIN_SENSORS:
                    t_name = next(
                        (
                            t
                            for t in matching_tables
                            if f"_{sensor}_" in t and t.endswith(rs)
                        ),
                        None,
                    )
                    sr_native = config.NATIVE_SR[ds][sensor]
                    raw = fetch_sensor_batch(
                        cursor,
                        t_name,
                        int(sr_native * CHUNK_SECONDS),
                        win_start,
                        target_run_id,
                    )

                    # Convert to numpy/list for fast transport across workers
                    data = np.array([r[0] for r in raw], dtype=np.float32)
                    chunk_data.append(data)

                # Yield 15-second raw block
                yield np.stack(chunk_data), class_id

            except Exception:
                continue


def run_training(model_class):
    os.makedirs(os.path.dirname(config.MODEL_SAVE_PATH), exist_ok=True)
    model = model_class().to(config.DEVICE)

    # Use 24 workers to fill the 1 TB RAM buffer,
    # but the workers themselves remain "lightweight"
    train_loader = DataLoader(
        VehicleStreamer("train"),
        batch_size=config.BATCH_SIZE,
        num_workers=24,
        pin_memory=True,
        prefetch_factor=2,
    )

    optimizer = optim.Adam(model.parameters(), lr=models.BASE_LR)
    criterion = nn.CrossEntropyLoss()
    scaler = GradScaler()

    for epoch in range(models.NUM_EPOCHS):
        model.train()
        for i, (raw_chunks, labels) in enumerate(train_loader):
            # 1. PARALLEL BATCH PROCESSING (The Fan-Out)
            # raw_chunks is [Batch, Sensors, 15*NativeSR]
            # We process the 15-second blocks into 1-second samples

            # For simplicity in this massive loop, we slice the 15s chunks
            # and process the 1s samples in a single vectorized batch call.
            # Shape becomes [Batch * 15, Sensors, 16000]

            # (Note: In a 120-core environment, this is where the CPU will
            # actually spike across all cores for a split second)
            features = preprocess.parallel_batch_process(raw_chunks, None)

            features = features.to(config.DEVICE, non_blocking=True)
            labels = labels.to(config.DEVICE, non_blocking=True)

            if isinstance(model, (models.ClassificationCNN, models.DetectionCNN)):
                features = preprocess.extract_mel_spectrogram(features)

            with autocast(device_type=config.DEVICE.type):
                outputs = model(features)
                loss = criterion(outputs, labels)

            optimizer.zero_grad()
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            if i >= config.TRAIN_STEPS_PER_EPOCH - 1:
                break
        print(f"Epoch {epoch} complete.")


if __name__ == "__main__":
    run_training(models.ClassificationCNN)
